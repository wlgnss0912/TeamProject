var btnDoubleCheck = false; 
function inputCheck() {
	return true;
}
function getEmail2() { //드롭다운박스 데이터값 추출
	var target = document.getElementById("email2");
	var index = target.options.selectedIndex;			
	var email2 = target.options[index].value;
	return email2;
}

window.onload = function () {

	//아이디 유효성검증(완료)
	var id = document.getElementById('id'); 
	id.onkeyup = function() { 	
		var loc = "http://localhost:9090/join";
		loc += "?cmd=ID" + "&id=" + id.value;
		//페이지 이동없이 db정보와 비교
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4) {
				if(xhr.status == 200) {
					var data = xhr.responseText;
					var span_id = document.getElementById('span_id');
					span_id.innerHTML = data;
					console.dir(data);
				}
			}
		}
		xhr.open('GET', loc, true);
		xhr.send();
	}
	id.onblur = function() { 	
		var loc = "http://localhost:9090/join";
		loc += "?cmd=ID" + "&id=" + id.value;
		//페이지 이동없이 db정보와 비교
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4) {
				if(xhr.status == 200) {
					var data = xhr.responseText;
					var span_id = document.getElementById('span_id');
					span_id.innerHTML = data;
					console.dir(data);
				}
			}
		}
		xhr.open('GET', loc, true);
		xhr.send();
	}


	//비밀번호 미입력, 길이(완료)
	var pwd = document.getElementById('pwd');
	pwd.onkeyup = function() {
		var span_pwd = document.getElementById('span_pwd');
		var span_ckpwd = document.getElementById('span_ckpwd');
		var pwdPattern = /^[A-Za-z0-9]{5,12}$/;
		var result2 = pwdPattern.test(pwd.value);

		if (pwd.value == "") {
			span_pwd.innerHTML = '<b class="red">비밀번호를 입력하세요</b>';
			return false; // 전송x
		} else if (!result2) {
			span_pwd.innerHTML = '<b class="red">잘못된 형식의 비밀번호입니다.</b>';
			return false;
		} else if (result2) {
			span_pwd.innerHTML = '';
		}
	}
	pwd.onblur = function() {
		var span_pwd = document.getElementById('span_pwd');
		var span_ckpwd = document.getElementById('span_ckpwd');
		var pwdPattern = /^[A-Za-z0-9]{5,12}$/;
		var result2 = pwdPattern.test(pwd.value);

		if (pwd.value == "") {
			span_pwd.innerHTML = '<b class="red">비밀번호를 입력하세요</b>';
			return false; // 전송x
		} else if (!result2) {
			span_pwd.innerHTML = '<b class="red">잘못된 형식의 비밀번호입니다.</b>';
			return false;
		} else if (result2) {
			span_pwd.innerHTML = '';
		}
	}

	//비밀번호 불일치 확인
	var ckpwd = document.getElementById('ckpwd');
	ckpwd.onblur = function() {
		var span_pwd = document.getElementById('span_pwd');
		var span_ckpwd = document.getElementById('span_ckpwd');
		var pwdPattern = /^[A-Za-z0-9]{5,12}$/;
		var result2 = pwdPattern.test(pwd.value);
		if (ckpwd.value == "") {
			span_ckpwd.innerHTML = '<b class="red">비밀번호를 확인하세요.</b>';
			return false; // 전송x
		}
		else if ((!result2) || (pwd.value != ckpwd.value)) {
			span_pwd.innerHTML = ''; 
			span_ckpwd.innerHTML = '<b class="red">비밀번호가 일치하지 않습니다.</b>';
			return false; // 전송x
		} else {
			span_ckpwd.innerHTML = '';
		}
	}


	//이름 유효성 검증(완료)
	var name = document.getElementById('name');
	name.onblur = function() {
		var span_name = document.getElementById('span_name');
		var namePattern = /^[가-힣]{2,6}$/; // 한글로 이뤄진 2~6자리 이름
		var result3 = namePattern.test(name.value);
		if(name.value == "") {
			span_name.innerHTML = '<b class="red">이름을 입력하세요.</b>';
			return false;
		} else if ( !result3 ) {
			span_name.innerHTML = '<b class="red">이름을 확인하세요.</b>';
			return false;
		} else {
			span_name.innerHTML = '';
		}
	}


	//닉네임 유효성 검증(닉네임없으면 아이디로 대체하기 추가해야해)
	var nicname = document.getElementById('nicname');
	nicname.onkeyup = function() {
		var loc = "http://localhost:9090/join";
		loc += "?cmd=NICNAME" + "&nicname=" + nicname.value;
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4) {
				if(xhr.status == 200) {
					var data = xhr.responseText;
					var span_nic = document.getElementById('span_nic');
					span_nic.innerHTML = data;
				}
			}
		}
		xhr.open('GET', loc, true);
		xhr.send();
	}

	//이메일 유효성검증
	var email1 = document.getElementById('email1');
	var span_email = document.getElementById('span_email');
	email1.onblur = function() {
		var email2 = getEmail2();
		var html = "";
		if(email1.value == '' || email2 == '') {
			html = "<b class='red'>이메일을 입력하세요</b>";
			span_email.innerHTML = html;
		} else {
			var email = email1.value + '@' + email2;
			var loc = "http://localhost:9090/join";
			loc += "?cmd=EMAIL" + "&email=" + email;
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if(xhr.readyState == 4) {
					if(xhr.status == 200) {
						var data = xhr.responseText;
						span_email.innerHTML = data;
					}
				}
			}
			xhr.open('GET', loc, true);
			xhr.send();
		}
	}
	var email2 = document.getElementById('email2');
	email2.onblur = function() {
		var email2 = getEmail2();
		if(email1.value == '' || email2 == '') {
			html = "<b class='red'>이메일을 입력하세요</b>";
			span_email.innerHTML = html;
		} else {
			var email = email1 + '@' + email2;
			var loc = "http://localhost:9090/join";
			loc += "?cmd=EMAIL" + "&email=" + email;
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if(xhr.readyState == 4) {
					if(xhr.status == 200) {
						var data = xhr.responseText;
						span_email.innerHTML = data;
					}
				}
			}
			xhr.open('GET', loc, true);
			xhr.send();
		}
	}

	//주민등록번호 유효성검증(완료)
	var rnn1 = document.getElementById('rrn1');
	var rrn2 = document.getElementById('rrn2');
	var span_rrn = document.getElementById('span_rrn');
	rrn1.onblur = function() {
		var rrn = rrn1.value + rrn2.value;
		var pattern = /^[0-9]{13}$/;
		var result = pattern.test(rrn);
		console.dir('rrn1 패턴일치' + result + ' 주민등록번호길이=' + rrn.length + '주민번호= ' + rrn);
		if(rrn.length == 0) {
			var html = "<b class='red'>주민등록번호를 입력하세요</b>";
			span_rrn.innerHTML = html;
		} else if(result) {
			var loc = "http://localhost:9090/join";
			loc += "?cmd=RRN" + "&rrn=" + rrn;
			console.dir('주소 ' + loc);
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if(xhr.readyState == 4) {
					if(xhr.states == 200) {
						var data = xhr.responseText;
						console.dir('rrn1 ajax데이터= ' + data);
						span_rrn.innerHTML = data;
					}
				}
			}
			xhr.open('GET', loc, true);
			xhr.send();
		} else {
			var html = "<b class='red>잘못된 주민등록번호입니다.</b>";
			span_rrn.innerHTML = html;
		}
	}
	rrn2.onblur = function() {
		var rrn = rrn1.value + rrn2.value;
		var pattern = /^[0-9]{13}$/;
		var result = pattern.test(rrn);
		console.dir('rrn2 패턴일치' + result + '주민등록번호길이=' + rrn.length + '주민번호= ' + rrn);
		if(rrn.length == 0) {
			var html = "<b class='red'>주민등록번호를 입력하세요</b>";
			span_rrn.innerHTML = html;
		} else if(result) {
			var loc = "http://localhost:9090/join";
			loc += "?cmd=RRN" + "&rrn=" + rrn;
			console.dir('주소 ' + loc);
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if(xhr.readyState == 4) {
					if(xhr.states == 200) {
						var data = xhr.responseText;
						console.dir('rrn2 ajax 데이터= ' + data);
						span_rrn.innerHTML = data;
					}
				}
			}
			xhr.open('GET', loc, true);
			xhr.send();
		} else {
			var html = "<b class='red>잘못된 주민등록번호입니다.</b>";
			span_rrn.innerHTML = html;
		}
	}



	var btnSearch = document.getElementById('btnSearch');
	btnSearch.onclick = function() { //우편번호 검색버튼 클릭
		var html = 'join_newwin_Search.html'; 
		var name = '우편번호 찾기';
		var features = 'height=400, width=400'; 	
		window.open(html, name, features); 
		//window.open("URL", "새창이름","새창의옵션")
	}



	function getGender() { //라디오박스 데이터값 추출
		var genders = document.getElementsByName('gender');
		for(var i=0; i<genders.length; i++) {
			if(genders[i].checked) {
				gender = genders[i].value;
				return gender;
			}
		}
	}


	var form = document.getElementById('join');
	form.onsubmit = function() {
		//데이터받아오기
		var id = document.getElementById('id').value; 
		var btnDouble = document.getElementById('btnDouble');
		var pwd = document.getElementById('pwd').value;
		var ckpwd = document.getElementById('ckpwd').value;
		var name = document.getElementById('name').value;
		var gender = getGender();
		var email1 = document.getElementById('email1').value;
		var email2 = getEmail2();
		var rrn1 = document.getElementById('rrn1').value;
		var rrn2 = document.getElementById('rrn2').value;
		var address1 = document.getElementById('address1'); // 주소부분은 아직 처리하지 않음
		var address2 = document.getElementById('address2');
		var address3 = document.getElementById('address3');
		var tel1 = document.getElementById('tel1').value;
		var tel2 = document.getElementById('tel2').value;
		var tel3 = document.getElementById('tel3').value;

		//성별 유효성체크(완료)
		if ( gender == 'male') { 
			if ( !(( rrn[6]==1) || (rrn[6]==3)) ) {
				alert('성별이 잘못 체크되었습니다.');
				return false;
			}
		} else if (gender == 'female') {
			if( !((rrn[6]==2) || (rrn[6]==4)) ) {
				alert('성별이 잘못 체크되었습니다.');
				return false;
			}
		}












		//전화번호 유효성체크(완료)
		var tel = tel1+tel2+tel3;
		var telPattern = /^01[0-1][\d]{3,4}[\d]{4}$/;
		var result6 = telPattern.test(tel);
		if( !result6 && (tel !='') ) {
			alert('전화번호가 잘못되었습니다. 다시 입력하세요.');
			return false;
		}


		//아이디 중복체크
		if ( !btnDoubleCheck ) { // false이면
			alert('아이디 중복확인이 필요합니다.'); 
			return false;
		}
		alert('회원가입되었습니다.');
		return true; // 전송o
	}
}


