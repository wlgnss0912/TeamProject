window.onload = function() {
	
	var btnJoin = document.getElementById("btnJoin");
	btnJoin.onclick = function() {
		location.href="/view/join_member.html";
	}
	
 
  	var btnLogin = document.getElementById("btnLogin");
	btnLogin.onsubmit = function() {
		var id = document.getElementById("id").value;
		var passwd = document.getElementById("passwd").value;
		
		var loc = "http://localhost:9090/login";
		loc += "?id=" + id + "&passwd=" + passwd;
		
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4) {
				if(xhr.status == 200) {
					var data = xhr.responseText;
					alert(data);
				}
			}
		}
		xhr.open('GET', loc, true);
		xhr.send();
	}
}