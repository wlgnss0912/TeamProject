package team.prj.board.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import team.prj.board.vo.BoardVo;

public class DBCon {
	private String driver	= "oracle.jdbc.OracleDriver";
	private String url		= "jdbc:oracle:thin:@localhost:1521:xe";
	private String user		= "prj";
	private String password	= "1234";
	
	Connection        conn  = null;
	
	public Connection getConnection() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public void close() {
		try {
			if(conn != null) conn.close();
		} catch (SQLException e) {			
			e.printStackTrace();
		}
	}
	
	
}
