package team.prj.board.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.internal.OracleCallableStatement;
import team.prj.board.db.DBCon;
import team.prj.board.vo.BoardMenuVo;
import team.prj.board.vo.BoardVo;

public class BoardDao {

	//입력받은 번호에 해당하는 게시물의 정보를 전부 가져온다.
	public BoardVo getBoard(int inseq) {
		BoardVo vo = null;
		
		Connection conn = null;
		CallableStatement cstmt = null;
		
		try {
			DBCon db = new DBCon();
			conn = db.getConnection();
			String sql = "CALL PKG_BOARD.GET_BOARD_VIEW(?,?,?,?,?,?,?,?,?,?)";
			cstmt = conn.prepareCall(sql);
			
			cstmt.setInt(1, inseq);
			cstmt.registerOutParameter(2, Types.NUMERIC);
			cstmt.registerOutParameter(3, Types.VARCHAR);
			cstmt.registerOutParameter(4, Types.VARCHAR);
			cstmt.registerOutParameter(5, Types.VARCHAR);
			cstmt.registerOutParameter(6, Types.VARCHAR);
			cstmt.registerOutParameter(7, Types.NUMERIC);
			cstmt.registerOutParameter(8, Types.VARCHAR);
			cstmt.registerOutParameter(9, Types.VARCHAR);
			cstmt.registerOutParameter(10, Types.NUMERIC);
			
			
			cstmt.executeQuery();
			
			int seq = cstmt.getInt(2);
			String title = cstmt.getString(3);
			String cont = cstmt.getString(4);
			String id = cstmt.getString(5);
			String nick = cstmt.getString(6);
			int hit = cstmt.getInt(7);
			String topic = cstmt.getString(8);
			String rdate = cstmt.getString(9);
			int likes = cstmt.getInt(10);
			
			vo = new BoardVo(seq, title, cont, id, nick, hit, topic, rdate, likes);
			
			System.out.println(vo.toString());
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return vo;
	}
	
	//메뉴 리스트를 불러온다.
	public List<BoardMenuVo> getMenuList() {
		List<BoardMenuVo> mvo = new ArrayList<BoardMenuVo>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
		DBCon db = new DBCon();
		
		conn=db.getConnection();
		String sql = "";
			sql = "select topic_num, topic from menus order by topic_num asc";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int topicNum = rs.getInt("topic_num");
				String topic = rs.getString("topic");
				BoardMenuVo vo = new BoardMenuVo(topicNum, topic);
				mvo.add(vo);
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
				
		return mvo;
	}
	
	//게시글을 생성하고, 생성된 게시글의 번호를 받아 온다.
	public String getAndWrite(String title, String cont, String id, int topicNum) {
		String seq = null;
		
		Connection conn = null;
		CallableStatement cstmt = null;
		
		try {
		DBCon db = new DBCon();
		conn = db.getConnection();
		String sql = "CALL PKG_BOARD.SET_BOARD_CREATE(?,?,?,?,?)";
			cstmt = conn.prepareCall(sql);
			
			cstmt.setString(1, title);
			cstmt.setString(2, cont);
			cstmt.setString(3, id);
			cstmt.setInt(4, topicNum);
			cstmt.registerOutParameter(5, Types.NUMERIC);
			
			
			cstmt.executeQuery();
			
			seq = Integer.toString(cstmt.getInt(5));
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return seq;
	}
	
	//UpdateForm에서 입력받은 값 저장한다.
	public void setUpdate(int seq, String title, String cont, String id, int topicNum) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		DBCon db = new DBCon();
		
		try {
		conn = db.getConnection();
		String sql = "UPDATE BOARDS SET TITLE=?, CONT=?, TOPIC_NUM=?";
			   sql+= " WHERE SEQ=? AND ID=?";
			pstmt = conn.prepareCall(sql);
			
			pstmt.setString(1, title);
			pstmt.setString(2, cont);
			pstmt.setInt(3, topicNum);
			pstmt.setInt(4, seq);
			pstmt.setString(5, id);
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void boardDelete(int seq, String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		DBCon db = new DBCon();
		try {
			conn = db.getConnection();
			String sql = "DELETE BOARDS";
				   sql+= " WHERE SEQ=? AND ID=?";
				pstmt = conn.prepareCall(sql);
				
				pstmt.setInt(1, seq);
				pstmt.setString(2, id);
				
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
	}
	
	//게시판 전체 조회
	public List<BoardVo> selectAllBoard(int page){
		
		Connection conn = null;
		CallableStatement cstmt = null;
		Statement		  stmt  = null;
		PreparedStatement pstmt = null;
		ResultSet         rs    = null;
		
		//1번 페이지 1~10
        //2번 페이지 11~20        
        int startNum = (page-1)*5+1;
        int endNum = page*5;
        
        List<BoardVo> list = new ArrayList<BoardVo>();
       
        	DBCon db = null;
		try {
			db = new DBCon();
			conn = db.getConnection();
      
			String sql = "SELECT *"; 
			sql       += " FROM (SELECT * FROM (SELECT ROWNUM AS ROW_NUM, BOARDS.* FROM BOARDS ORDER BY SEQ DESC)";
			sql       += " WHERE ROW_NUM >=?)";
			sql       += " WHERE ROW_NUM <=?";
            
			pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, startNum);
            pstmt.setInt(2, endNum);
            
            rs = pstmt.executeQuery();
            while(rs.next()){
            	int seq = rs.getInt("seq");
				String title     = rs.getString("title");
				String cont      = rs.getString("cont");
				String id        = rs.getString("id");
				int    hit       = rs.getInt("hit");
				int    topic = rs.getInt("topic_num");
				String rdate     = rs.getString("rdate");
				int    likes      = rs.getInt("likes");
                
				BoardVo vo = new BoardVo(seq, title, cont, id, hit, topic, rdate, likes);
				
                list.add(vo);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
				try {
					if(rs!=null)    rs.close();
					if(pstmt!=null) pstmt.close();
					db.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        }
        return list;
	}
	
	//전체 게시물 수 카운트
	public int getAllcount() {
		
		Connection conn = null;
		Statement		  stmt  = null;
		PreparedStatement pstmt = null;
		ResultSet         rs    = null;
		
		DBCon db = null;
		int count = 0;
		
		try {
			db   = new DBCon();
			conn = db.getConnection();
			
			String sql ="SELECT COUNT(*) AS COUNT";
			sql       += " FROM BOARDS";
			
			stmt      = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				count = rs.getInt("COUNT");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
				try {
					if(rs!=null)   rs.close();
					if(pstmt!=null)pstmt.close();
					db.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		System.out.println("db count : " + count);
		return count;
	}
	
	//일부 게시물 수 카운트
	public int getcount(String topic_num) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet         rs    = null;
		
		DBCon db = null;
		int count = 0;
		
		try {
			db   = new DBCon();
			conn = db.getConnection();
			
			String sql ="SELECT COUNT(*) AS COUNT";
			sql       += " FROM BOARDS";
			sql       += " WHERE TOPIC_NUM = ?";
			
			pstmt      = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(topic_num));
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt("COUNT");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
				try {
					if(rs!=null)   rs.close();
					if(pstmt!=null)pstmt.close();
					db.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		System.out.println("db count 1 : " + count);
		return count;
	}
	
	//게시판 검색
	public List<BoardVo> searchBoard(String searchWord, int page) {
		List<BoardVo> list = new ArrayList<BoardVo>();
		
        int startNum = (page-1)*5+1;
        int endNum   = page*5;
        
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		
		DBCon db = null;
		try {
			db = new DBCon();
			
			conn = db.getConnection();
			
			String sql = "{CALL PKG_BOARD.GET_BOARD_SEARCH(?,?,?,?)}";
			cstmt = conn.prepareCall(sql);
			cstmt.setString(1, '%' + searchWord + '%');
			cstmt.setInt(2, startNum);
			cstmt.setInt(3, endNum);
			cstmt.registerOutParameter(4, oracle.jdbc.OracleTypes.CURSOR);
			
			cstmt.executeQuery();
			
			OracleCallableStatement ocstmt = (OracleCallableStatement) cstmt;
			rs = ocstmt.getCursor(4);
			
			while(rs.next()){
				int    seq       = rs.getInt("seq");
				String title     = rs.getString("title");
				String cont      = rs.getString("cont");
				String id        = rs.getString("id");
				int    hit       = rs.getInt("hit");
				int    topic     = rs.getInt("topic_num");
				String rdate     = rs.getString("rdate");
				int    likes     = rs.getInt("likes");

				BoardVo vo = new BoardVo(seq, title, cont, id, hit, topic, rdate, likes);

				list.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)   rs.close();
				if(cstmt!=null)cstmt.close();
				db.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//자유게시판 조회
	public List<BoardVo> selectFreeBoard(int page, String topic_num) {
		Connection conn = null;
		CallableStatement cstmt = null;
		Statement		  stmt  = null;
		PreparedStatement pstmt = null;
		ResultSet         rs    = null;
		
		//1번 페이지 1~10
        //2번 페이지 11~20        
        int startNum = (page-1)*5+1;
        int endNum = page*5;
        
        List<BoardVo> list = new ArrayList<BoardVo>();
       
        	DBCon db = null;
		try {
			db = new DBCon();
			conn = db.getConnection();
      
			String sql = "SELECT *"; 
			sql       += " FROM (SELECT * FROM (SELECT ROWNUM AS ROW_NUM, BOARDS.* FROM BOARDS WHERE TOPIC_NUM = ? ORDER BY SEQ DESC)";
			sql       += " WHERE ROW_NUM >=?)";
			sql       += " WHERE ROW_NUM <=?";
            
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(topic_num));
            pstmt.setInt(2, startNum);
            pstmt.setInt(3, endNum);
            
            rs = pstmt.executeQuery();
            while(rs.next()){
            	int seq = rs.getInt("seq");
				String title     = rs.getString("title");
				String cont      = rs.getString("cont");
				String id        = rs.getString("id");
				int    hit       = rs.getInt("hit");
				int    topic = rs.getInt("topic_num");
				String rdate     = rs.getString("rdate");
				int    likes      = rs.getInt("likes");
                
				BoardVo vo = new BoardVo(seq, title, cont, id, hit, topic, rdate, likes);
				
                list.add(vo);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
				try {
					if(rs!=null)    rs.close();
					if(pstmt!=null) pstmt.close();
					db.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        }
        return list;
	}

	public List<BoardVo> searchBoard2(String searchWord, int page, String topic_num) {
		List<BoardVo> list = new ArrayList<BoardVo>();

		int startNum = (page-1)*5+1;
		int endNum   = page*5;

		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;

		DBCon db = null;
		try {
			db = new DBCon();

			conn = db.getConnection();

			String sql = "{CALL PKG_BOARD.GET_BOARD_SEARCH_WITH_NUM(?,?,?,?,?)}";
			cstmt = conn.prepareCall(sql);
			cstmt.setString(1, '%' + searchWord + '%');
			cstmt.setInt(2, startNum);
			cstmt.setInt(3, endNum);
			cstmt.setInt(4, Integer.parseInt(topic_num));
			cstmt.registerOutParameter(5, oracle.jdbc.OracleTypes.CURSOR);

			cstmt.executeQuery();

			OracleCallableStatement ocstmt = (OracleCallableStatement) cstmt;
			rs = ocstmt.getCursor(5);

			while(rs.next()){
				int    seq       = rs.getInt("seq");
				String title     = rs.getString("title");
				String cont      = rs.getString("cont");
				String id        = rs.getString("id");
				int    hit       = rs.getInt("hit");
				int    topic     = rs.getInt("topic_num");
				String rdate     = rs.getString("rdate");
				int    likes     = rs.getInt("likes");

				BoardVo vo = new BoardVo(seq, title, cont, id, hit, topic, rdate, likes);

				list.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)   rs.close();
				if(cstmt!=null)cstmt.close();
				db.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	// 좋아요 누를 시 처리.
	public void setLikes(int seq, String id) {
		Connection conn = null;
		CallableStatement cstmt = null;

		try {
			DBCon db = new DBCon();
			conn = db.getConnection();
			String sql = "CALL PKG_BOARD.SET_BOARD_LIKES(?,?)";
			cstmt = conn.prepareCall(sql);
			cstmt.setInt(1, seq);
			cstmt.setString(2, id);

			cstmt.execute();


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	//좋아요 버튼 값 받아오기
	public ArrayList<String> getLikes(int seq, String id) {
		ArrayList<String> arr = new ArrayList<String>();
		Connection conn = null;
		CallableStatement cstmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		if(id!=null) {

			try {
				DBCon db = new DBCon();
				conn = db.getConnection();
				String sql = "CALL PKG_BOARD.GET_BOARD_LIKES(?,?,?,?)";
				cstmt = conn.prepareCall(sql);

				cstmt.setInt(1, seq);
				cstmt.setString(2, id);
				cstmt.registerOutParameter(3, Types.NUMERIC);		
				cstmt.registerOutParameter(4, Types.NUMERIC);		

				cstmt.executeQuery();

				String chk = Integer.toString(cstmt.getInt(3));
				String cnt = Integer.toString(cstmt.getInt(4));

				arr.add(0, chk);
				arr.add(1, cnt);



			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(cstmt!=null)cstmt.close();
					if(conn!=null)conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} else {
			try {
				DBCon db = new DBCon();
				conn = db.getConnection();
				String sql = "SELECT LIKES FROM BOARDS WHERE SEQ = ?";
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setInt(1, seq);
				
				rs = pstmt.executeQuery();
				
				rs.next();
				
				String chk = "0";
				String cnt = Integer.toString(rs.getInt(1));
				arr.add(0,chk);
				arr.add(1,cnt);
				
				

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(rs!=null)rs.close();
					if(cstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return arr;
	}


}


