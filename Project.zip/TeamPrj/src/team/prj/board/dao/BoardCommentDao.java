package team.prj.board.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.OracleCallableStatement;
import team.prj.board.db.DBCon;
import team.prj.board.vo.BoardCommentVo;

public class BoardCommentDao {

	public void setCommentCreate(int seq, int parent_seq, String sessionId, String cont) {
		Connection conn = null;
		CallableStatement cstmt = null;


		try {
			DBCon db = new DBCon();
			conn = db.getConnection();
			String sql = "{CALL PKG_COMMENT.SET_COMMENTS_CREATE(?,?,?,?)}";
			cstmt = conn.prepareCall(sql);

			cstmt.setInt(1, seq);
			cstmt.setInt(2, parent_seq);
			cstmt.setString(3, sessionId);
			cstmt.setString(4, cont);
			
			
			cstmt.executeUpdate();
			

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void setCommentDelete(int comment_seq, String sessionId) {
		Connection conn = null;
		CallableStatement cstmt = null;


		try {
			DBCon db = new DBCon();
			conn = db.getConnection();
			String sql = "{CALL PKG_COMMENT.SET_COMMENTS_DELETE(?,?)}";
			cstmt = conn.prepareCall(sql);

			cstmt.setInt(1, comment_seq);
			cstmt.setString(2, sessionId);
			

			cstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void setCommentUpdate(int comment_seq, String cont, String sessionId) {
		Connection conn = null;
		CallableStatement cstmt = null;


		try {
			DBCon db = new DBCon();
			conn = db.getConnection();
			String sql = "{CALL PKG_COMMENT.SET_COMMENTS_UPDATE(?,?,?)}";
			cstmt = conn.prepareCall(sql);

			cstmt.setInt(1, comment_seq);
			cstmt.setString(2, cont);
			cstmt.setString(3, sessionId);
			

			cstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<BoardCommentVo> setCommentView(int i_seq, int i_parent_seq) {
		List<BoardCommentVo> cmtList = new ArrayList<BoardCommentVo>();
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;

		try {
			DBCon db = new DBCon();

			conn=db.getConnection();
			String sql = "{CALL PKG_COMMENT.GET_COMMENTS_VIEW(?,?,?)}";
			cstmt = conn.prepareCall(sql);
			
			cstmt.setInt(1, i_seq);
			cstmt.setInt(2, i_parent_seq);
			cstmt.registerOutParameter(3, oracle.jdbc.OracleTypes.CURSOR);
			
			cstmt.execute();
			OracleCallableStatement ocstmt = (OracleCallableStatement) cstmt;
			
			rs = ocstmt.getCursor(3);

			while(rs.next()) {
				int comment_seq = rs.getInt(1);
				int seq = rs.getInt(2);
				int parent_seq = rs.getInt(3);
				String id = rs.getString(4);
				String cont = rs.getString(5);
				String rdate = rs.getString(6);
				String nicname = rs.getString(7);
				BoardCommentVo vo = new BoardCommentVo(comment_seq, seq, parent_seq, id, cont, rdate, nicname);
				cmtList.add(vo);
				
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			try {
				if(cstmt!=null)cstmt.close();
				if(conn!=null)conn.close();
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cmtList;
	}

}
