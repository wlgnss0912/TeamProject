package team.prj.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import team.prj.board.db.DBCon;
import team.prj.board.vo.MemberVo;

public class MemberDao {

	//로그인 확인을 위한 정보 가져오기
	public MemberVo getMember(String id) {
		System.out.println("MemberDao클래스의 getMember메소드");
		System.out.println("입력받은 id = " + id);
		MemberVo vo = null;

		Connection conn = null;
		DBCon db = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			db = new DBCon();
			conn = db.getConnection();

			String sql = "SELECT ID, PASSWD, NICNAME";
			sql += " FROM MEMBERS";
			sql += " WHERE ID=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			String chkId = "null";
			String chkPwd = "null";
			String chkNic = "null";
			//설마 rs.next() 한번 호출하고 나면 뒤에 못쓰는거?? ㅇㅇ...
			//System.out.println("데이터받니?rs.next()= " + rs.next()); 
			//위의 문장 없으니까 실행잘됨..;;;;
			if(rs.next()) { //rs.next() = true인데 왜 안들어와??
				chkId = rs.getString("ID");
				chkPwd = rs.getString("PASSWD");
				chkNic = rs.getString("NICNAME");
			} 
			vo = new MemberVo(chkId, chkPwd, chkNic);
			System.out.println("getMember결과: " + vo + "\n");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return vo;
	}


	//회원가입시, id중복확인버튼을 누르면 id값을 인자로받아 데이터검색해, 
	//중복되는 아이디가 있는지 검색
	public String getId(String id) {
		System.out.println("MemberDao클래스의 getId메소드 " + id);
		Connection conn = null;
		DBCon db = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String chkId = null;
		try {
			db = new DBCon();
			conn = db.getConnection();

			String sql = "SELECT ID";
			sql += " FROM MEMBERS";
			sql += " WHERE ID=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			//System.out.println("아이디받아오니?" + rs.next());
			if(rs.next()) {
				chkId = rs.getString("ID");
				System.out.println("chkId= " + chkId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return chkId;
	}

	//중복되는 닉네임 있는지 검색
	public String getNicname(String nicname) {
		System.out.println("MemberDao클래스의 getNicname메소드 ");
		System.out.println("입력받은 닉네임= " + nicname);
		Connection conn = null;
		DBCon db = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String chkNic = null;
		try {
			db = new DBCon();
			conn = db.getConnection();

			String sql = "SELECT NICNAME";
			sql += " FROM MEMBERS";
			sql += " WHERE NICNAME=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nicname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				chkNic = rs.getString("NICNAME");
				System.out.println("db의 결과 chkNic= " + chkNic);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return chkNic;
	}

	//중복되는 아이디 있는지 검색
	public String getEmail(String email) {
		System.out.println("MemberDao클래스의 getEmail메소드 ");
		System.out.println("입력받은 이메일= " + email);
		Connection con = null;
		DBCon db = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String chkEmail = null;
		try {
			db = new DBCon();
			con = db.getConnection();
			//System.out.println(con);
			
			String sql = "SELECT EMAIL";
			sql += " FROM MEMBERS";
			sql += " WHERE EMAIL=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			
			//System.out.println("sql문 실행하니?" + rs.next());
			if(rs.next()) {
				chkEmail = rs.getString("EMAIL");
				System.out.println("db결과 email= " + chkEmail);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				//자원은 쓰고나서 꼭 닫아주자...
				//오라클 Listener refused the connection with the following error: ORA-12519 TNS:no appropriate servcie hanlder found 에러 발생했었다
				//자원을 쓰고 안닫아주니까, 프로세스를 너무 많이 사용해서 문제생김
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return chkEmail;
	}


	public String getRRN(String rrn) {
		System.out.println("MemberDao클래스의 getRRN메소드 ");
		System.out.println("입력받은 rrn= " + rrn);

		Connection con = null;
		DBCon db = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String chkRRN = null;
		try {
			db = new DBCon();
			con = db.getConnection();
			
			String sql = "SELECT IDENTIFICATION";
			sql += " FROM MEMBERS";
			sql += " WHERE IDENTIFICATION=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, rrn);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				chkRRN = rs.getString("IDENTIFICATION");
				System.out.println("db결과 주민번호= " + chkRRN);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("주민번호 db결과= " + chkRRN);
		return chkRRN;
	}


}
