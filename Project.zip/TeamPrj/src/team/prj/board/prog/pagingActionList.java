package team.prj.board.prog;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.prj.board.controller.Action;
import team.prj.board.dao.BoardDao;
import team.prj.board.vo.BoardVo;
import team.prj.board.vo.Paging;

public class pagingActionList implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int page = 1;
		
		if(request.getParameter("page")!= null) {//클라이언트가 요청한 page param가 null이 아니라면
			page = Integer.parseInt(request.getParameter("page"));//그것으로 설정
		}
		
		BoardDao boardDao = new BoardDao();
		List<BoardVo> boardList = boardDao.selectAllBoard(page);

		int count = boardDao.getAllcount();
		
		Paging paging = new Paging();
		paging.setTotalCount(count);
		paging.setPage(page);
		
		request.setAttribute("boardList", boardList);
		request.setAttribute("paging", paging);
		
		String path = "/layout/whole.jsp";
		request.getRequestDispatcher(path).forward(request, response);
	}

}
