package team.prj.board.prog;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.prj.board.dao.MemberDao;
import team.prj.board.vo.MemberVo;

@WebServlet("/login")
public class login_check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		loginProc(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		loginProc(request, response);
	}
	
	private void loginProc(HttpServletRequest request, HttpServletResponse response) {
		//넘어온 정보받기(request)
		String id = request.getParameter("id");
		String passwd = request.getParameter("passwd");
		
		//DB조회정보 받기
		MemberDao dao = new MemberDao();
		MemberVo vo = dao.getMember(id);
		System.out.println("조회된정보 " + vo);
		
		String chkid = vo.getId();
		String chkpass = vo.getPasswd();
		String nicname = vo.getNicname();
		
		try {
			String result = "";
			if( !(id.equals(chkid)) ) {
				result = "idfalse";
			} else if( !(passwd.equals(chkpass)) ) {
				result = "passfalse";
			} else {
				result = nicname;
			}
			System.out.println("result->" + result);
			
			request.setAttribute("result", result);
			RequestDispatcher rd = request.getRequestDispatcher("/view/loginResult.jsp");
			rd.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
