package team.prj.board.prog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import team.prj.board.controller.Action;
import team.prj.board.dao.BoardDao;
import team.prj.board.vo.BoardMenuVo;
import team.prj.board.vo.BoardVo;

public class ActionBoardUpdateForm implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//세션 ID를 불러 온다. ${userId}를 쓰면 ID를 불러 옴.
		HttpSession session = request.getSession(true);
		String id = (String) session.getAttribute("ID");
		request.setAttribute("userId", id);
		
		String path = "/view/boardUpdateForm.jsp";
		int seq = Integer.parseInt(request.getParameter("seq"));
		List<BoardMenuVo> mvo = new ArrayList<BoardMenuVo>();
		
		
		
		BoardDao dao = new BoardDao();
		BoardVo vo = dao.getBoard(seq);
		

		String cont = vo.getCont();
		cont = cont.replace("\r\n", "<br>");
		vo.setCont(cont);
		
		
		mvo = dao.getMenuList();
		
		
		
		request.setAttribute("menus", mvo);
		request.setAttribute("board", vo);
		
		request.getRequestDispatcher(path).forward(request, response);
	}

}
