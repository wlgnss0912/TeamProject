package team.prj.board.prog;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import team.prj.board.controller.Action;
import team.prj.board.dao.BoardDao;

public class ActionBoardWrite implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//세션 ID를 불러 온다. ${userId}를 쓰면 ID를 불러 옴.
		HttpSession session = request.getSession(true);
		String id = (String) session.getAttribute("ID");
		request.setAttribute("userId", id);
		
		int topicNum = Integer.parseInt(request.getParameter("topic"));
		String title = request.getParameter("title");
		String cont = request.getParameter("cont");
		
		
		BoardDao dao = new BoardDao();
		String seq = dao.getAndWrite(title, cont, id, topicNum);
		
		
		String path = "/board?cmd=BOARDVIEW&seq="+seq;
		
		request.getRequestDispatcher(path).forward(request, response);
		
		
	}

}
