package team.prj.board.prog;

import java.util.regex.Pattern;

import team.prj.board.dao.MemberDao;

public class JoinCheck {

	public String idCheck(String id) {
		//db조회
		MemberDao dao = new MemberDao();
		String chkId = dao.getId(id);
		String pattern = "^[a-z0-9]{2,20}$";
		boolean result = Pattern.matches(pattern, id);
		System.out.println("JoinCheck클래스 idCheck메소드");
		System.out.println("패턴일치결과= " + result + " id= " + id + " db중복= " + chkId);
		//정규표현식으로 문자열검증
		//Pattern.matches("정규식","검증할 문자열");

		String html = "<b ";
		if(id == "") {
			html += "class='red'>아이디를 입력하세요.";
		} else if (id.length()< 2 || id.length()>20 ) {
			html += "class='red'>최소 2자, 최대 20자까지 작성가능";
		} else if(!result) {
			html += "class='red'>잘못된 형식의 아이디 입니다.";
		} else if( id.equals(chkId) ) {
			html += "class='red'>이미 사용중인 아이디입니다.";
		} else {
			html += "class='blue'>사용가능한 아이디입니다.";
		}
		html += "</b>";
		System.out.println("html = " + html + "\n");
		return html;
	}

	public String nicCheck(String nicname) {
		//db조회
		MemberDao dao = new MemberDao();
		String chkNic = dao.getNicname(nicname);

		String pattern1 = "^[A-Za-z0-9]{1,15}$";
		String pattern2 = "^[가-힣A-Za-z0-9]{1,8}$";
		boolean result1 = Pattern.matches(pattern1, nicname);
		boolean result2 = Pattern.matches(pattern2, nicname);
		System.out.println("JoinCheck클래스 nicCheck메소드");
		System.out.println("패턴일치결과1 = " + result1 + ", " + "패턴일치결과2 = " + result2  + "닉네임= " + nicname + "db중복= " + chkNic );
		
		String html = "<b ";
		if(nicname == "") {
			html += ">";
		} else if((result1 || result2) && !(nicname.equals(chkNic)) ) {
			html += "class='blue'>사용가능한 닉네임입니다.";
		} else {
			html += "class='red'>사용불가능한 닉네임입니다.";
		}
		html += "</b>";
		System.out.println("html = " + html + "\n");
		return html;
	}

	public String emailCheck(String email) {
		//db조회
		MemberDao dao = new MemberDao();
		String chkEmail = dao.getEmail(email);
		//에러발생 : Invalid escape sequence (valid ones are  \b  \t  \n  \f  \r  \"  \'  \\ )
		//           -> \를 출력하고 싶으면 \\를 써야한다.
		String pattern = "^[a-z][a-z0-9_-]{1,11}@([a-z\\d\\.-]+)\\.([a-z\\.]{2,6})$";
		boolean result = Pattern.matches(pattern, email);
		System.out.println("JoinCheck클래스 emailCheck메소드");
		System.out.println("패턴일치결과= " + result + " 이메일= " + email + " db중복= " + chkEmail);
		
		String html = "<b ";
		if (email.equals("@")){ 
			html += "class='red'>이메일을 입력하세요";
		} else if ( !result ) {
			html += "class='red'>잘못된 형식의 이메일입니다. 다시 입력하세요.";
		} else if (email.equals(chkEmail)) {
			html += "class='red'>이미 사용중인 이메일입니다.";
		} else {
			html += "class='blue'>사용가능한 이메일입니다.";
		}
		html += "<b>";

		return html;
	}

	public String rrnCheck(String rrn) {
		//db조회
		MemberDao dao = new MemberDao();
		String chkRRN = dao.getRRN(rrn);
		
		//들어온 문자열 유효성검증
		int n = 2;
		int sum=0;
		String pattern = "^[0-9]{13}$";
		boolean result = Pattern.matches(pattern, rrn);
		int rrnNumber [] = new int[13];
		System.out.println("주민등록번호 숫자로 변경");
		for(int i=0; i<rrnNumber.length; i++) {
			rrnNumber[i] = Integer.parseInt(rrn.substring(i,i+1));
			System.out.println(rrnNumber[i]);
		}
		String html = "<b ";
		if (rrn.length() == 0) { 
			html = "class='red'>주민등록번호를 입력하세요.</b>";
			System.out.println("html= " + html + "패턴결과= " + result);
		} else if ( result ) {	//주민등록번호 모든 자리수를 다 입력했다면 유효검증 실행
			for (int i=0; i<rrn.length()-1; i++){
				sum += rrnNumber[i] * n;
				if (n == 9) {
					n = 1;	
				}	
				n++;
			}
			System.out.println("rrn.length()-1= " + (rrn.length()-1));
			int validCheck = 11 - (sum % 11);
			System.out.println("validCheck= " + validCheck + "유효성체크rrnNumber[12]=" + rrnNumber[12]);
			switch (validCheck) {
			  //case 1,2,3,4,5,6,7,8,9: break;
				case 10: validCheck=0; break;
				case 11: validCheck=1; break;
			}
			if ( rrnNumber[12] != validCheck ) {
				html ="class='red'>잘못된 주민등록번호입니다.</b>";
				System.out.println(html);
			} 
		} else {
			html ="class='red'>잘못된 주민등록번호입니다. 다시 입력하세요.</b>";
			System.out.println(html);
		}
		return html;
	}
	
	
	
	
	
	
}
