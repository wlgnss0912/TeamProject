package team.prj.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import team.prj.board.dao.BoardDao;

@WebServlet("/likes")
public class Likes extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		controlFunc(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		controlFunc(request, response);
	}
	private void controlFunc(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//세션 ID를 불러 온다. ${userId}를 쓰면 ID를 불러 옴.
		HttpSession session = request.getSession(true);
		String id = (String) session.getAttribute("ID");
		
		int seq = Integer.parseInt(request.getParameter("seq"));
		String on = request.getParameter("on");
		
		String html = "";
		BoardDao dao = new BoardDao();
		
		ArrayList<String> arr = new ArrayList<String>();
		
		//만약 클릭해서 호출되었고, 아이디가 있다면 추천수 변동.
		if(on.equals("click")&&id!=null) {
			dao.setLikes(seq,id);
			System.out.println("셋");
		}
		
		//html 정보를 불러옴.
		//id가 null이면 pstmt, 그렇지 않으면 cstmt 사용함.
		arr = dao.getLikes(seq,id);
		
		
		//id가 null값이면 버튼 작동 X, 로그인 하라는 alert용 id.
		html += "<button ";
		if(id!=null) 
			html += "id='like'";
		else 
			html+= "id='logLike'";
		
		//arr 값이 0이면 (추천하지 않았으면) 회색 클래스.
		//그렇지 않으면 초록색 클래스.
		html += "class='";
		if(arr.get(0).equals("0")) {
			html += "grayLikes";
			System.out.println("회색");
		} else {
			html += "greenLikes";
			System.out.println("초록");
		}
		html += "'>";
		
		// 추천수
		html += arr.get(1);
		html += "</button>";
		
		
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print(html);
		out.flush();
		out.close();
	}
}
