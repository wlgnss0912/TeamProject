package team.prj.board.controller;

import team.prj.board.prog.ActionBoardDelete;
import team.prj.board.prog.ActionBoardDeleteForm;
import team.prj.board.prog.ActionBoardUpdate;
import team.prj.board.prog.ActionBoardUpdateForm;
import team.prj.board.prog.ActionBoardView;
import team.prj.board.prog.ActionBoardWrite;
import team.prj.board.prog.ActionBoardWriteForm;
import team.prj.board.prog.paging2ActionList;
import team.prj.board.prog.pagingActionList;
import team.prj.board.prog.search2ActionList;
import team.prj.board.prog.searchActionList;

public class ActionFactory {

	public Action getAction(String cmd) {
		Action action = null;
		
		switch (cmd) {
		case "BOARDVIEW":
			action = new ActionBoardView(); 
			break;
		case "BOARDUPDATE":
			action = new ActionBoardUpdate();
			break;
		case "BOARDUPDATEFORM":
			action = new ActionBoardUpdateForm();
			break;
		case "BOARDWRITE":
			action = new ActionBoardWrite();
			break;
		case "BOARDWRITEFORM":
			action = new ActionBoardWriteForm();
			break;
		case "BOARDDELETEFORM":
			action = new ActionBoardDeleteForm();
			break;
		case "BOARDDELETE":
			action = new ActionBoardDelete();
			break;
		case "PAGING":    
			action = new pagingActionList(); 
			break;
		case "PAGING2":    
			action = new paging2ActionList(); 
			break;
		case "SEARCH":
			action = new searchActionList();
			break;
		case "SEARCH2":
			action = new search2ActionList();
			break;
		}
		
		return action;
	}

}
