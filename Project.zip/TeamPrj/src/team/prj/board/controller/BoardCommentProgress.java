package team.prj.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import team.prj.board.dao.BoardCommentDao;
import team.prj.board.vo.BoardCommentVo;

@WebServlet("/boardcmt")
public class BoardCommentProgress extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		controlFunc(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		controlFunc(request,response);
	}

	private void controlFunc(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			
		request.setCharacterEncoding("utf-8");
		
		BoardCommentDao cmtDao = new BoardCommentDao();
		HttpSession session = request.getSession(true);
		
		String sessionId = "";
		
		if((String) session.getAttribute("ID")!=null) sessionId = (String) session.getAttribute("ID");
		String oper = request.getParameter("oper");
		String stringSeq = request.getParameter("seq");
		String stringComment_seq = request.getParameter("comment_seq");
		String stringParent_seq = request.getParameter("parent_seq");
		String stringNumChk = request.getParameter("numChk");
		String cont = request.getParameter("cont");
		int seq = 0;
		int comment_seq = 0;
		int parent_seq = 0;
		int numChk = 0;
		
		if(stringSeq!=null)	seq = Integer.parseInt(stringSeq);
		if(stringComment_seq!=null) comment_seq = Integer.parseInt(stringComment_seq);
		if(stringParent_seq!=null) parent_seq = Integer.parseInt(stringParent_seq);
		if(stringNumChk!=null) numChk= Integer.parseInt(stringNumChk);
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String html = "";
		
		switch (oper) {
		case "CREATE":
			cmtDao.setCommentCreate(seq,parent_seq,sessionId,cont);
			
			break;
		case "DELETE":
			cmtDao.setCommentDelete(comment_seq,sessionId);
			
			break;
		case "UPDATE":
			cmtDao.setCommentUpdate(comment_seq,cont,sessionId);
			break;
		case "VIEW":
			List<BoardCommentVo> cmtList = new ArrayList<BoardCommentVo>();
			cmtList = cmtDao.setCommentView(seq,parent_seq);
			if (parent_seq==0) { //전체 댓글을 부른다.
				for (int i = 0; i < cmtList.size(); i++) {
					BoardCommentVo vo = cmtList.get(i);
					html+="<form name='mainCmtList' id='formChk"+i+"'>";
					html+=" <input type='hidden' name='comment_userid' value='"+vo.getId()+"'/>";
					html+=" <input type='hidden' name='parent_seq' value='"+0+"'/>";
					html+=" <input type='hidden' name='comment_seq' value='"+vo.getComment_seq()+"'/>";
					html+=" <input type='hidden' name='seq' value='"+vo.getSeq()+"'/>";
					html+="<p class=''>"+vo.getNicname()+"</p>";
					html+="<p class=''>"+vo.getRdate()+"</p>";
					html+="<p class=''>"+vo.getCont()+"</p>";
					if(sessionId.equals(vo.getId())) {
					html+="<a id='cmtSubView"+i+"'>답글 달기</a>";
					}
					html+="<a id='cmtListView"+i+"'>자세히 보기</a>";
					if(sessionId.equals(vo.getId())) {
						html+="<button type='button' name = 'cmtUpdateBtn'>수정</button>";
						html+="<input type='submit' value='삭제'>";
					html+="</form>";
					html+="<form name='cmtUdtMainForm' style='display:none;'>";
					html+=" <input type='hidden' name='parent_seq' value='"+0+"'/>";
					html+=" <input type='hidden' name='comment_seq' value='"+vo.getComment_seq()+"'/>";
					html+="<textarea name='cont' placeholder='코멘트를 입력하세요.'>"+vo.getCont()+"</textarea>";
					html+="<input type='submit' value='작성'>";
					html+="</form>";
					html+="<div id='cmtSub"+i+"' style='display:none;'>";
					html+=" <form name='commentSub'>";
					html+="<input type='hidden' name='numChk' value='"+i+"'/>";
					html+="<input type='hidden' name='seq' value='"+vo.getSeq()+"'>";
					html+="<input type='hidden' name='parent_seq' value='"+vo.getComment_seq()+"'>";
					html+="<textarea name='cont' placeholder='코멘트를 입력하세요.'></textarea>";
					html+="<input type='submit' value='작성'>";
					}
					html+="</form>";
					html+="</div>";
					html+="<div id='cmtList"+i+"'></div>";	// 대댓글 보는 곳
					html+="<a id='cmtListClose"+i+"' style='display:none;'>접기</a>"; 
					html+="<br>";
				}
			} else { //하위 댓글을 다시 부른다
				for (int i = 0; i < cmtList.size(); i++) {
					BoardCommentVo vo = cmtList.get(i);
					html+="<form name='subCmtForm'>";
					html+=" <input type='hidden' name='comment_userid' value='"+vo.getId()+"'/>";
					html+=" <input type='hidden' name='parent_seq' value='"+vo.getParent_seq()+"'/>";
					html+=" <input type='hidden' name='comment_seq' value='"+vo.getComment_seq()+"'/>";
					html+=" <input type='hidden' name='seq' value='"+vo.getSeq()+"'/>";
					html+=" <input type='hidden' name='numChk' value='"+numChk+"'/>";
					html+="<p class=''>"+vo.getNicname()+"</p>";
					html+="<p class=''>"+vo.getRdate()+"</p>";
					html+="<p class=''>"+vo.getCont()+"</p>";
					if(sessionId.equals(vo.getId())) {
						html+="<button type='button' name='cmtUpdateBtn'>수정</button>";
						html+="<input type='submit' name='deleteSubmit' value='삭제'>";
						html+="</form>";
						html+="<form name='cmtUdtSubForm' style='display:none;'>";
						html+="<input type='hidden' name='numChk' value='"+numChk+"'/>";
						html+=" <input type='hidden' name='parent_seq' value='"+vo.getParent_seq()+"'/>";
						html+=" <input type='hidden' name='comment_seq' value='"+vo.getComment_seq()+"'/>";
						html+="<textarea name='cont' placeholder='코멘트를 입력하세요.'>"+vo.getCont()+"</textarea>";
						html+="<input type='submit' value='작성'>";
					}
					html+="</form><br>";
				}
				
			}
			
			break;

		default:
			System.out.println("boardcmt error - oper is \""+oper+"\"");
			break;
		}
		out.print(html);
		out.flush();
		out.close();
		
		} catch (NullPointerException e) {
			
		}
		
	}

}
