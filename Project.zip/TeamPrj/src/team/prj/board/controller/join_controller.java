package team.prj.board.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.prj.board.prog.JoinCheck;

@WebServlet("/join")
public class join_controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		joinMember(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		joinMember(request, response);
	}
	
	
	private void joinMember(HttpServletRequest request, HttpServletResponse response) {
		//넘어온 정보 받기(request)
		String cmd = request.getParameter("cmd");
		System.out.println("cmd= " + cmd);
		//유효성검증을 위해 이동
		JoinCheck check = new JoinCheck();
		String html = "";
		switch(cmd) {
		case "ID":
			//넘어온정보받기(request)
			String id = request.getParameter("id");
			//아이디 중복확인 결과받기
			html = check.idCheck(id);
			break;
		case "NICNAME" :
			String nicname = request.getParameter("nicname");
			html = check.nicCheck(nicname);
			break;
		case "EMAIL" :
			String email = request.getParameter("email");
			html = check.emailCheck(email);
			break;
		case "RRN" :
			System.out.println("가입컨트롤러 RRN");
			String rrn = request.getParameter("rrn");
			html = check.rrnCheck(rrn);
			break;
		}

		try {
			//내려보내는정보(response)
			response.setContentType("text/html; charset=utf-8");
			PrintWriter out = response.getWriter();
			out.print(html);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
}
