package team.prj.board.vo;

public class BoardMenuVo {
	//Field
	private int topicNum;
	private String topic;
	//Constuctor
	public BoardMenuVo() {}
	public BoardMenuVo(int topicNum, String topic) {
		super();
		this.topicNum = topicNum;
		this.topic = topic;
	}
	//Getter, Setter
	public int getTopicNum() {
		return topicNum;
	}
	public void setTopicNum(int topicNum) {
		this.topicNum = topicNum;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	@Override
	public String toString() {
		return "BoardMenuVo [topicNum=" + topicNum + ", topic=" + topic + "]";
	}
}
