package team.prj.board.vo;

public class BoardVo {
	//field
	private int seq;
	private String title;
	private String cont;
	private String id;
	private String nick;
	private int hit;
	private String topic;
	private int topic_num;
	private String rdate;
	private int likes;
	
	//constructor
	public BoardVo() {}
	
	public BoardVo(int seq, String title, String cont, String id, int hit, int topic_num, String rdate, int likes) {
		super();
		this.seq = seq;
		this.title = title;
		this.cont = cont;
		this.id = id;
		this.hit = hit;
		this.topic_num = topic_num;
		this.rdate = rdate;
		this.likes = likes;
	}

	public BoardVo(int seq, String title, String cont, String id,String nick, int hit, String topic, String rdate, int likes) {
		this.seq = seq;
		this.title = title;
		this.cont = cont;
		this.id = id;
		this.nick = nick;
		this.hit = hit;
		this.topic = topic;
		this.rdate = rdate;
		this.likes = likes;
	}
	
	//Getter, Setter
	
	public int getSeq() {
		return seq;
	}
	public int getTopic_num() {
		return topic_num;
	}

	public void setTopic_num(int topic_num) {
		this.topic_num = topic_num;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCont() {
		return cont;
	}
	public void setCont(String cont) {
		this.cont = cont;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	
	
	//toString
	@Override
	public String toString() {
		return "BoardVo [seq=" + seq + ", title=" + title + ", cont=" + cont + ", id=" + id + ", nick=" + nick
				+ ", hit=" + hit + ", topic=" + topic + ", rdate=" + rdate + ", likes=" + likes + "]";
	}
	
}
