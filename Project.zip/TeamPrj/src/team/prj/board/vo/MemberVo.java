package team.prj.board.vo;

public class MemberVo {
	private String id;
	private String passwd;
	private String nicname;
	private String name;
	private String gender;
	private String email;
	private String rrn;
	private String addr;
	private String zipcode;
	private String phone;

	public MemberVo() { }
	public MemberVo(String id, String passwd, String nicname, String name, String gender, String email, String rrn,
			String addr, String zipcode, String phone) {
		this.id = id;
		this.passwd = passwd;
		this.nicname = nicname;
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.rrn = rrn;
		this.addr = addr;
		this.zipcode = zipcode;
		this.phone = phone;
	}
	public MemberVo(String id, String passwd, String nicname) {
		this.id = id;
		this.passwd = passwd;
		this.nicname = nicname;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getNicname() {
		return nicname;
	}
	public void setNicname(String nicname) {
		this.nicname = nicname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRrn() {
		return rrn;
	}
	public void setRrn(String rrn) {
		this.rrn = rrn;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "MemberVo [id=" + id + ", passwd=" + passwd + ", nicname=" + nicname + ", name=" + name + ", gender="
				+ gender + ", email=" + email + ", rrn=" + rrn + ", addr=" + addr + ", zipcode=" + zipcode + ", phone="
				+ phone + "]";
	}
}
