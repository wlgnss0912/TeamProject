package team.prj.board.vo;

public class BoardCommentVo {
	//field
	private int comment_seq;
	private int seq;
	private int parent_seq;
	private String id;
	private String cont;
	private String rdate;
	private String nicname;
	
	//constructor
	public BoardCommentVo() {}
	public BoardCommentVo(int comment_seq, int seq, int parent_seq, String id, String cont, String rdate,
			String nicname) {
		super();
		this.comment_seq = comment_seq;
		this.seq = seq;
		this.parent_seq = parent_seq;
		this.id = id;
		this.cont = cont;
		this.rdate = rdate;
		this.nicname = nicname;
	}
	
	//getter,setter
	public int getComment_seq() {
		return comment_seq;
	}
	public void setComment_seq(int comment_seq) {
		this.comment_seq = comment_seq;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public int getParent_seq() {
		return parent_seq;
	}
	public void setParent_seq(int parent_seq) {
		this.parent_seq = parent_seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCont() {
		return cont;
	}
	public void setCont(String cont) {
		this.cont = cont;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public String getNicname() {
		return nicname;
	}
	public void setNicname(String nicname) {
		this.nicname = nicname;
	}
	//toString
	@Override
	public String toString() {
		return "BoardCommentVo [comment_seq=" + comment_seq + ", seq=" + seq + ", parent_seq=" + parent_seq + ", id="
				+ id + ", cont=" + cont + ", rdate=" + rdate + ", nicname=" + nicname + "]";
	}
	
	
	
}
