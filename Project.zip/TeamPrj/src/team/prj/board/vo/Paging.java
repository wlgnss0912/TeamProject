package team.prj.board.vo;

public class Paging {
	private int page = 1;        //현재 페이지(get)
	private int totalCount;      //전체  레코드 수(get)
	private int beginPage;       //출력 시작 페이지
	private int endPage;         //출력 끝 페이지
	private int displayRow = 5;  //한페이지에 몇개의 로우 (선택set) 1~5
	private int displayPage = 10; //한페이지에 몇 개의 페이지 (선택 set) 1~10
	boolean prev;                //prev 버튼이 보일건지?
	boolean next;				 //next 버튼이 보일건지?
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) { //전체의 페이지  수(get)
		//setTotalCount()를 꼭 호출해야 paging이 된다
		//paging()함수를 setTotalCount()를 호출했을때 자동 호출 되게 한다.
		this.totalCount = totalCount;
		paging();
	}
	public int getBeginPage() {
		return beginPage;
	}
	public void setBeginPage(int beginPage) {
		this.beginPage = beginPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public int getDisplayRow() {
		return displayRow;
	}
	public void setDisplayRow(int displayRow) {
		this.displayRow = displayRow;
	}
	public boolean isPrev() {
		return prev;
	}
	public void setPrev(boolean prev) {
		this.prev = prev;
	}
	public boolean isNext() {
		return next;
	}
	public void setNext(boolean next) {
		this.next = next;
	}
	
	private void paging() {
		// prev, next, beginPage, endPage를 계산해서 만든다.
        // 2+9 = 11, 11/10 = 1, 1*10 = 10
        // 10+9 = 19, 19/10 = 1, 1*10 = 10
		
        // 11+9 = 20, 20/10 = 2, 2*10 = 20
        // 20+9 = 29, 29/10 = 2, 2*10 = 20
        // 111+9 = 120 120/10 = 12, 12*10 = 120
		
		endPage = (int)Math.ceil(page/(double)displayPage)*displayPage; // (1/10.0) = ceil(0.1) = (int)1.0 = 1*10 
		System.out.println("endPage : " + endPage);
		
		beginPage = endPage - (displayPage - 1);
		System.out.println("beginPage : " + beginPage);
		
		//글 11개
		//11/5 = 1.1(올림) 3페이지
		//3=? 3/5
		int totalPage = (int)Math.ceil(totalCount/(double)displayRow);
		
		if(totalPage<endPage) {
			endPage = totalPage;
			next = false;
		}else {
			next = true;
		}
		prev = (beginPage==1) ? false : true;
		System.out.println("endPage : " + endPage);
		System.out.println("totalPage : " + totalPage);
	}
}
